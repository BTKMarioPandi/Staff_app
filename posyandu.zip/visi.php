<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Posyandu - Rimbo Panjang</title>
	<meta charset="UTF-8">
	<meta name="description" content="X Gym Fitness HTML Template">
	<meta name="keywords" content="fitness, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="frontend/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="frontend/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="frontend/css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="frontend/css/flaticon.css"/>
	<link rel="stylesheet" href="frontend/css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="frontend/css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section">
		<a href="index.php" class="site-logo">
			<img src="frontend/img/logo.png" alt="" width="60px">
		</a>
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="#">Profil</a></li>
			<li><a class="active" href="visi.php">Visi & Misi</a></li>
			<li><a href="admin/" target="_blank">Login</a></li>
		</ul>
	</header>
	<div class="clearfix"></div>
	<!-- Header section end -->



	<!-- Feature section -->
	<section class="feature-section">
		<div class="container">
			<div class="row justify-content-md-center">
				<div class="col-lg-12">
					<div class="section-title text-center">
						<h2>VISI & MISI </h2>
						<hr>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="icon-box-item">
						
						<h4>Visi</h4>
						<p>Memantau perkembangan kesehatan masyarakat setempat demi terciptanya pemingkatan kesehatan masyarakat. Melaksanakan  kegiatam posyandu secara bertanggung jawab umtuk tercapai masa depan kleugra yamg lbih baik </p>
					</div>
				</div>   
				<div class="col-md-6">
					<div class="icon-box-item">
						
						<h4>Misi</h4>
						<p>meningkatakn  pelayanan yang bermutu merata dan terjangkau oleh masyarakt. Mendorong kemandirian masyarakat untuk hidup bersih dan sehat. Meningkatakn profesional sumber daya manusia. Menggerakn pembangunan yg berwawasan kesehatan</p>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Feature section end -->

	
	<!-- Footer section -->
	<footer class="footer-section set-bg" style="background: currentColor;#eeee">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-sm-6">
					<div class="footer-widget">
						<h4>Lokasi</h4>
						<div class="fw-info-box">
							<img src="frontend/img/icons/1.png" alt="">
							<div class="fw-info-text">
								<p>Rimbo Panjang - Pekanbaru</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="footer-widget">
						<h4>Kontak</h4>
						<div class="fw-info-box">
							<img src="frontend/img/icons/2.png" alt="">
							<div class="fw-info-text">
								<p>+1 (603)535-4592</p>
								<p>+1 (603)535-4556</p>
							</div>
						</div>
					</div>
				</div>
			
		
			</div>
			<div class="row">
				<div class="col-md-6 order-2 order-md-1">
					<div class="copyright"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Posyandu<i class="fa fa-heart" aria-hidden="true"> Rimbo Panjang
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
				</div>
				<div class="col-md-6 order-1 order-md-2">
					<ul class="footer-menu">
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end -->
									
	<!--====== Javascripts & Jquery ======-->
	<script src="frontend/js/jquery-3.2.1.min.js"></script>
	<script src="frontend/js/bootstrap.min.js"></script>
	<script src="frontend/js/jquery.slicknav.js"></script>
	<script src="frontend/js/owl.carousel.min.js"></script>
	<script src="frontend/js/circle-progress.min.js"></script>
	<script src="frontend/js/main.js"></script>

	</body>
</html>
