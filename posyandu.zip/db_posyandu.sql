-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2020 at 08:14 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_posyandu`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_anak`
--

CREATE TABLE `tb_anak` (
  `anak_id` int(11) NOT NULL,
  `anak_nama` varchar(100) NOT NULL,
  `tgl_lahir_anak` date NOT NULL,
  `bb_lahir` varchar(100) NOT NULL,
  `ibu_id` int(11) NOT NULL,
  `kelompok_anak` varchar(100) NOT NULL,
  `kms` enum('0','1') NOT NULL,
  `jenis_kelamin` varchar(50) NOT NULL,
  `tgl_meninggal_anak` date NOT NULL,
  `penyebab_anak` varchar(256) NOT NULL,
  `kia` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_anak`
--

INSERT INTO `tb_anak` (`anak_id`, `anak_nama`, `tgl_lahir_anak`, `bb_lahir`, `ibu_id`, `kelompok_anak`, `kms`, `jenis_kelamin`, `tgl_meninggal_anak`, `penyebab_anak`, `kia`) VALUES
(10, 'Butet', '2020-06-30', '3kg', 2, 'fg', '0', 'Laki-Laki', '2020-06-24', 'sffw', '1'),
(11, 'ucokk', '2022-12-12', '12', 3, '1', '0', 'Laki-Laki', '0000-00-00', '', '1'),
(12, 'Ucok', '2020-07-03', '3kg', 2, 'Elit', '1', 'Laki-Laki', '2020-07-02', 'Sakit Hati', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_ibu`
--

CREATE TABLE `tb_ibu` (
  `ibu_id` int(11) NOT NULL,
  `ibu_nama` varchar(100) NOT NULL,
  `alamat` varchar(256) NOT NULL,
  `suami` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kelompok` varchar(100) NOT NULL,
  `tgl_meninggal` date NOT NULL,
  `penyebab` varchar(100) NOT NULL,
  `tahapan` enum('0','1') NOT NULL,
  `keadaan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_ibu`
--

INSERT INTO `tb_ibu` (`ibu_id`, `ibu_nama`, `alamat`, `suami`, `tgl_lahir`, `kelompok`, `tgl_meninggal`, `penyebab`, `tahapan`, `keadaan`) VALUES
(2, 'Fatimah', 'Pekanbaru', 'Toyib', '2020-07-03', '1', '2020-07-02', 'Sakit Hati', '1', 'Sehat'),
(4, 'Romla', 'Pekanbaru', 'Toyib', '2020-07-29', 'Elit', '0000-00-00', '', '1', 'Sehat');

-- --------------------------------------------------------

--
-- Table structure for table `tb_la_anak`
--

CREATE TABLE `tb_la_anak` (
  `la_id` int(11) NOT NULL,
  `anak_id` int(11) NOT NULL,
  `ibu_id` int(11) NOT NULL,
  `tgl_la_anak` date NOT NULL,
  `pelayanan` varchar(100) NOT NULL,
  `imunisasi_anak` varchar(100) NOT NULL,
  `tinggi_badan` varchar(100) NOT NULL,
  `berat_badan` varchar(100) NOT NULL,
  `umur` varchar(100) NOT NULL,
  `imt` varchar(100) NOT NULL,
  `bb_tb` varchar(100) NOT NULL,
  `bb_u` varchar(100) NOT NULL,
  `tb_u` varchar(100) NOT NULL,
  `imt_u` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_la_anak`
--

INSERT INTO `tb_la_anak` (`la_id`, `anak_id`, `ibu_id`, `tgl_la_anak`, `pelayanan`, `imunisasi_anak`, `tinggi_badan`, `berat_badan`, `umur`, `imt`, `bb_tb`, `bb_u`, `tb_u`, `imt_u`) VALUES
(1, 10, 2, '2020-06-18', 'ljjl', 'ada', 'l', '12', '1', '2', '2', '2', '2', '2'),
(2, 10, 2, '2020-07-24', 'Pertama', 'prima', '2', 'KJDWW', '2', '2', '2', '2', '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tb_la_ibu`
--

CREATE TABLE `tb_la_ibu` (
  `id_li` int(11) NOT NULL,
  `ibu_id` int(11) NOT NULL,
  `tgl_la` date NOT NULL,
  `kehamilan` varchar(100) NOT NULL,
  `resiko` varchar(100) NOT NULL,
  `lila` varchar(100) NOT NULL,
  `pmt` enum('0','1') NOT NULL,
  `hasil` varchar(100) NOT NULL,
  `darah` varchar(100) NOT NULL,
  `imunisasi` varchar(100) NOT NULL,
  `yodium` enum('0','1') NOT NULL,
  `vitamin` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_la_ibu`
--

INSERT INTO `tb_la_ibu` (`id_li`, `ibu_id`, `tgl_la`, `kehamilan`, `resiko`, `lila`, `pmt`, `hasil`, `darah`, `imunisasi`, `yodium`, `vitamin`) VALUES
(2, 4, '2020-06-23', 'Proses', 'Rendah', 'asd', '0', 'ada', 'ada', 'ada', '0', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pus`
--

CREATE TABLE `tb_pus` (
  `id_pus` int(11) NOT NULL,
  `ibu_id` int(11) NOT NULL,
  `lila` varchar(100) NOT NULL,
  `jml_h` varchar(100) NOT NULL,
  `jml_m` varchar(100) NOT NULL,
  `imunisasi` varchar(100) NOT NULL,
  `kotrasepsi` varchar(100) NOT NULL,
  `energi` enum('0','1') NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pus`
--

INSERT INTO `tb_pus` (`id_pus`, `ibu_id`, `lila`, `jml_h`, `jml_m`, `imunisasi`, `kotrasepsi`, `energi`, `tgl`) VALUES
(1, 4, '', '1', '1', 'Lancar', 'sss`', '1', '2020-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `user_id` int(11) NOT NULL,
  `user_nama` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role` varchar(150) NOT NULL,
  `foto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`user_id`, `user_nama`, `username`, `password`, `role`, `foto`) VALUES
(2, 'Mario Pandi', 'mario', 'c4ca4238a0b923820dcc509a6f75849b', 'Admin', 'an.jpg'),
(3, 'septi', 'septi', 'c4ca4238a0b923820dcc509a6f75849b', 'Admin', 'titn.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_anak`
--
ALTER TABLE `tb_anak`
  ADD PRIMARY KEY (`anak_id`);

--
-- Indexes for table `tb_ibu`
--
ALTER TABLE `tb_ibu`
  ADD PRIMARY KEY (`ibu_id`);

--
-- Indexes for table `tb_la_anak`
--
ALTER TABLE `tb_la_anak`
  ADD PRIMARY KEY (`la_id`);

--
-- Indexes for table `tb_la_ibu`
--
ALTER TABLE `tb_la_ibu`
  ADD PRIMARY KEY (`id_li`);

--
-- Indexes for table `tb_pus`
--
ALTER TABLE `tb_pus`
  ADD PRIMARY KEY (`id_pus`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_anak`
--
ALTER TABLE `tb_anak`
  MODIFY `anak_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_ibu`
--
ALTER TABLE `tb_ibu`
  MODIFY `ibu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_la_anak`
--
ALTER TABLE `tb_la_anak`
  MODIFY `la_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_la_ibu`
--
ALTER TABLE `tb_la_ibu`
  MODIFY `id_li` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_pus`
--
ALTER TABLE `tb_pus`
  MODIFY `id_pus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
