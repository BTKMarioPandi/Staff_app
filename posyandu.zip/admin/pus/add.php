<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>
<?php include '../../_config/config.php'; 
$title = "Data PUS/WUS";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <!-- Page Heading -->
          
          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Tambah Data PUS/WUS</h1>

          <div class="row">

            <div class="col-lg-10">

              <!-- Circle Buttons -->
              <div class="card shadow mb-4">
	                <div class="card-header py-3">
	                  <h6 class="m-0 font-weight-bold text-primary">Form Tambah Data PUS/WUS</h6>
	                </div>
	       

	                	<form class="form-vertikal" method="post" action="proses.php" enctype="multipart/form-data">
	                		<div class="form-group">
	                			<label class="col-sm-3">Nama Ibu</label>
	                			<div class="col-sm-7">
                				 <select name="ibu_id" class="form-control select1" required>
				                 <option value="">--Pilih Nama Ibu--</option>
				                 <?php 
				                 $sql_ibu = mysqli_query($con, "SELECT * FROM tb_ibu ") or die(mysqli_error($con));
				                 while ($data= mysqli_fetch_array($sql_ibu)){
				                  echo '<option value = "'.$data['ibu_id'].'">'.$data['ibu_nama'].'</option>';
				                 }
				                  ?>
				      			</select>
	                			</div>
	                		</div>
	                		
	                				<input type="hidden" name="lila" class="form-control">
	                		<div class="form-group">
	                			<label class="col-sm-3">Jumlah Anak Hidup</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="jml_h" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Jumlah Anak Meninggal</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="jml_m" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Imunisasi</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="imunisasi" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Jenis Kotrasepsi</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="jks" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Energi Kronis</label>
	                			<div class="col-sm-7">
	                				<select name="ek" class="form-control">
	                					<option value="1">Pakai</option>
	                					<option value="0">Tidak Pakai</option>
	                				</select>
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Tanggal</label>
	                			<div class="col-sm-7">
	                				<input type="date" name="tgl" class="form-control">
	                			</div>
	                		</div>
	                		<hr>

	                		<div class="form-group">
	                			<label class="col-sm-2"></label>
	                			<button type="submit" name="add" class="btn btn-success">Simpan</button>
	                			</div>

	                	</form>

    					</div>

		          </div>
		        </div>
          

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php';
 ?>

</body>

</html>
<?php } ?>