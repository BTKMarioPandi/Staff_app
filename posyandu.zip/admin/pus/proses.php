<?php
require_once "../../_config/config.php";

$id 		="";
$nama_ibu 	= trim(mysqli_real_escape_string($con, $_POST['ibu_id']));
$lila 	= trim(mysqli_real_escape_string($con, $_POST['lila']));
$jm_h		= trim(mysqli_real_escape_string($con, $_POST['jml_h']));
$jm_m 	= trim(mysqli_real_escape_string($con, $_POST['jml_m']));
$imunisasi 	= trim(mysqli_real_escape_string($con, $_POST['imunisasi']));
$kontra 	= trim(mysqli_real_escape_string($con, $_POST['jks']));
$energi 		= trim(mysqli_real_escape_string($con, $_POST['ek']));
$tgl 	= trim(mysqli_real_escape_string($con, $_POST['tgl']));

if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_pus VALUES ('$id','$nama_ibu','$lila','$jm_h','$jm_m','$imunisasi','$kontra','$energi','$tgl')") or die (mysqli_error($con));
	echo "<script>window.location='pus.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	mysqli_query($con, "UPDATE tb_pus SET ibu_id='$nama_ibu',lila='$lila',jml_h='$jm_h',jml_m='$jm_m',imunisasi='$imunisasi',kotrasepsi='$kontra',energi='$energi',tgl='$tgl' WHERE id_pus='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='pus.php';</script>";
}
?>