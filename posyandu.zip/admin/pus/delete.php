<?php
require_once "../../_config/config.php";
$id = @$_GET['id'];
mysqli_query($con, "DELETE FROM tb_pus WHERE id_pus = '$id'") or die (mysqli_error($con));
echo "<script>window.location='pus.php';</script>";
?>