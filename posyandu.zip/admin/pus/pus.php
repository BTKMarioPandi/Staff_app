<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php include '../../_config/config.php'; 
$title = "Data PUS/WUS";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">DATA PUS/WUS</h1>
            <a href="add.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data PUS/WUS</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Ibu</th>
                      <!-- <th>LILA</th> -->
                      <th>Jml Anak H</th>
                      <th>Jml Anak M</th>
                      <th>Imunisasi</th>
                      <th>Jenis Kontrasepsi</th>
                      <th>Energi Kronis</th>
                      <th>Tanggal</th>
                      <th><i class="fa fa-cogs"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_pus INNER JOIN tb_ibu ON tb_pus.ibu_id = tb_ibu.ibu_id") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) {
                          $a=$data['energi'];
                          if ($a=="1") {
                             $en="Pakai";

                           }else{
                            $en="Tidak Pakai";
                           } ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['ibu_nama'] ?></td>
                         <!--  <td><?= $data['lila'] ?></td> -->
                          <td><?= $data['jml_h'] ?></td>
                          <td><?= $data['jml_m'] ?></td>
                          <td><?= $data['imunisasi'] ?></td>
                          <td><?= $data['kotrasepsi'] ?></td>
                          <td><?= $en ?></td>
                          <td><?= $data['tgl'] ?></td>
                          <td class="text-center">
                           <a href="edit.php?id=<?=$data['id_pus']?>" onclick="edit()" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                            <a href="delete.php?id=<?=$data['id_pus']?>" onclick="hapus()" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>

                    </table>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>