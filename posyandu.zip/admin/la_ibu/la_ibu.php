<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php include '../../_config/config.php'; 
$title = "Data Layanan Ibu";
include 'head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Layanan Ibu</h1>
            <a href="add.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Layanan Ibu</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Ibu</th>
                      <th>Tanggal Layanan</th>
                      <th>Kehamilan</th>
                      <th>Resiko</th>
                      <!-- <th>Lila</th> -->
                      <th>PMT</th>
                      <th>Hasil</th>
                      <th>Darah</th>
                      <th>Imunisasi</th>
                      <th>Yodium</th>
                      <th>Vitamin A</th>
                      <th><i class="fa fa-cogs"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_la_ibu INNER JOIN tb_ibu ON tb_la_ibu.ibu_id = tb_ibu.ibu_id") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) {
                            $a= $data['pmt'];
                          $b= $data['yodium'];
                          $c= $data['vitamin'];

                          if ($a=="1") {
                             $kms = "Ya";
                           }else{
                            $kms = "Tidak";
                           }
                           if ($b=="1") {
                             $kia = "Ya";
                           }else{
                            $kia = "Tidak";
                           }
                           if ($c=="1") {
                             $vt = "Ya";
                           }else{
                            $vt = "Tidak";
                           }
                           ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['ibu_nama'] ?></td>
                          <td><?= $data['tgl_la'] ?></td>
                          <td><?= $data['kehamilan'] ?></td>
                          <td><?= $data['resiko'] ?></td>
                          <!-- <td><?= $data['lila'] ?></td> -->
                          <td><?= $kms ?></td>
                          <td><?= $data['hasil'] ?></td>
                          <td><?= $data['darah'] ?></td>
                          <td><?= $data['imunisasi'] ?></td>
                          <td><?= $kia ?></td>
                          <td><?= $vt ?></td>
                          <td class="text-center">
                           <a href="edit.php?id=<?=$data['id_li']?>" onclick="edit()" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                            <a href="delete.php?id=<?=$data['id_li']?>" onclick="hapus()" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>

                    </table>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include 'footer.php'; ?>

</body>

</html>
<?php } ?>