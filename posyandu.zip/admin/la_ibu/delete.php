<?php
require_once "../../_config/config.php";
$id = @$_GET['id'];
mysqli_query($con, "DELETE FROM tb_la_ibu WHERE id_li = '$id'") or die (mysqli_error($con));
echo "<script>window.location='pus.php';</script>";
?>