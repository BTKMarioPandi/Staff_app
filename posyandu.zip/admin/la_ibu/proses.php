<?php
require_once "../../_config/config.php";

$id 		="";
$nama_ibu 	= trim(mysqli_real_escape_string($con, $_POST['ibu_id']));
$tgl 	= trim(mysqli_real_escape_string($con, $_POST['tl']));
$khml	= trim(mysqli_real_escape_string($con, $_POST['kh']));
$rsk	= trim(mysqli_real_escape_string($con, $_POST['rs']));
$lila 	= trim(mysqli_real_escape_string($con, $_POST['ll']));
$pmt 	= trim(mysqli_real_escape_string($con, $_POST['pmt']));
$hasil 	= trim(mysqli_real_escape_string($con, $_POST['hp']));
$darah 	= trim(mysqli_real_escape_string($con, $_POST['ttd']));
$imun 	= trim(mysqli_real_escape_string($con, $_POST['imn']));
$yodi 	= trim(mysqli_real_escape_string($con, $_POST['ky']));
$vita 	= trim(mysqli_real_escape_string($con, $_POST['va']));

if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_la_ibu VALUES ('$id','$nama_ibu','$tgl','$khml','$rsk','$lila','$pmt','$hasil','$darah','$imun','$yodi','$vita')") or die (mysqli_error($con));
	echo "<script>window.location='la_ibu.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	mysqli_query($con, "UPDATE tb_la_ibu SET ibu_id='$nama_ibu',tgl_la='$tgl',kehamilan='$khml',resiko='$rsk',lila='$lila',pmt='$pmt',hasil='$hasil',darah='$darah',imunisasi='$imun',yodium='$yodi',vitamin='$vita' WHERE id_li='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='la_ibu.php';</script>";
}
?>