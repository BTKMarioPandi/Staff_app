<?php
require_once "../../_config/config.php";

$id 		="";
$nama_anak 	= trim(mysqli_real_escape_string($con, $_POST['nama_anak']));
$tgl_lahir 	= trim(mysqli_real_escape_string($con, $_POST['tgl_lahir']));
$bb_lahir	= trim(mysqli_real_escape_string($con, $_POST['bb_lahir']));
$nama_ibu 	= trim(mysqli_real_escape_string($con, $_POST['ibu_id']));
$kelompok 	= trim(mysqli_real_escape_string($con, $_POST['kelompok']));
$kms 		= trim(mysqli_real_escape_string($con, $_POST['kms']));
$jk 		= trim(mysqli_real_escape_string($con, $_POST['jk']));
$tgl_mngl 	= trim(mysqli_real_escape_string($con, $_POST['tgl_mngl']));
$penyebab 	= trim(mysqli_real_escape_string($con, $_POST['penyebab']));
$kia 		= trim(mysqli_real_escape_string($con, $_POST['kia']));


if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_anak VALUES ('$id','$nama_anak','$tgl_lahir','$bb_lahir','$nama_ibu','$kelompok','$kms','$jk','$tgl_mngl','$penyebab','$kia')") or die (mysqli_error($con));
	echo "<script>window.location='anak.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	mysqli_query($con, "UPDATE tb_anak SET anak_nama='$nama_anak',tgl_lahir_anak='$tgl_lahir',bb_lahir='$bb_lahir',ibu_id='$nama_ibu',kelompok_anak='$kelompok',kms='$kms',jenis_kelamin='$jk',tgl_meninggal_anak='$tgl_mngl',penyebab_anak='$penyebab',kia='$kia' WHERE anak_id='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='anak.php';</script>";
}
?>