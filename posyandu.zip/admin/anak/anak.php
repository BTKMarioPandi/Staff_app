<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>


<?php include '../../_config/config.php'; 
$title = "Data Anak";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include 'navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <a href="add.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Anak</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Anak</th>
                      <th>Tanggal Lahir</th>
                      <th>BB Lahir</th>
                      <th>Nama Ibu</th>
                      <th>Kelompok</th>
                      <th>KMS</th>
                      <th>Jenis Kelamin</th>
                      <!-- <th>Tgl Meninggal</th>
                      <th>Penyebab</th> -->
                      <th>KIA</th>
                      <th><i class="fa fa-cogs"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_anak INNER JOIN tb_ibu ON tb_anak.ibu_id = tb_ibu.ibu_id") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) {
                          $a= $data['kms'];
                          $b= $data['kia'];

                          if ($a=="1") {
                             $kms = "Punya";
                           }else{
                            $kms = "Tidak Punya";
                           }
                           if ($b=="1") {
                             $kia = "Sehat";
                           }else{
                            $kia = "Tidak Sehat";
                           } ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['anak_nama'] ?></td>
                          <td><?= $data['tgl_lahir_anak'] ?></td>
                          <td><?= $data['bb_lahir'] ?></td>
                          <td><?= $data['ibu_nama'] ?></td>
                          <td><?= $data['kelompok_anak'] ?></td>
                          <td><?= $kms ?></td>
                          <td><?= $data['jenis_kelamin'] ?></td>
                          <!-- <td><?= $data['tgl_meninggal_anak'] ?></td>
                          <td><?= $data['penyebab_anak'] ?></td> -->
                          <td><?= $kia ?></td>

                          <td class="text-center">
                           <a href="edit.php?id=<?=$data['anak_id']?>" onclick="edit()" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                            <a href="delete.php?id=<?=$data['anak_id']?>" onclick="hapus()" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>

                    </table>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>