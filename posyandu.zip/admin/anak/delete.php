<?php
require_once "../../_config/config.php";
$id = @$_GET['id'];
mysqli_query($con, "DELETE FROM tb_anak WHERE anak_id = '$id'") or die (mysqli_error($con));
echo "<script>window.location='anak.php';</script>";
?>