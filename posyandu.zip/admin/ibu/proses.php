<?php
require_once "../../_config/config.php";

$id 		="";
$nama_ibu 	= trim(mysqli_real_escape_string($con, $_POST['nama_ibu']));
$alamat 	= trim(mysqli_real_escape_string($con, $_POST['alamat']));
$suami		= trim(mysqli_real_escape_string($con, $_POST['suami']));
$tgl_lahir 	= trim(mysqli_real_escape_string($con, $_POST['tgl_lahir']));
$kelompok 	= trim(mysqli_real_escape_string($con, $_POST['kelompok']));
$tgl_mngl 	= trim(mysqli_real_escape_string($con, $_POST['tgl_meninggal']));
$pybab 		= trim(mysqli_real_escape_string($con, $_POST['penyebab']));
$tahapan 	= trim(mysqli_real_escape_string($con, $_POST['tahapan']));
$keadaan 	= trim(mysqli_real_escape_string($con, $_POST['keadaan']));


if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_ibu VALUES ('$id','$nama_ibu','$alamat','$suami','$tgl_lahir','$kelompok','$tgl_mngl','$pybab','$tahapan','$keadaan')") or die (mysqli_error($con));
	echo "<script>window.location='ibu.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	mysqli_query($con, "UPDATE tb_ibu SET ibu_nama='$nama_ibu',alamat='$alamat',suami='$suami',tgl_lahir='$tgl_lahir',kelompok='$kelompok',tgl_meninggal='$tgl_mngl',penyebab='$pybab',tahapan='$tahapan',keadaan='$keadaan' WHERE ibu_id='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='ibu.php';</script>";
}
?>