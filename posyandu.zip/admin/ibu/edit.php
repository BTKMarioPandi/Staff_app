<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>
<?php include '../../_config/config.php'; 
$title = "Data Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include 'navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <!-- Page Heading -->
          
          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Edit Data Ibu</h1>

          <div class="row">

            <div class="col-lg-10">

              <!-- Circle Buttons -->
              <div class="card shadow mb-4">
	                <div class="card-header py-3">
	                  <h6 class="m-0 font-weight-bold text-primary">Form Edit Data Ibu</h6>
	                </div>

	                <?php 
	                $id= @$_GET['id'];
	                $sql_costumer=mysqli_query($con, "SELECT * FROM tb_ibu WHERE ibu_id = '$id' ")or die (mysqli_error($con));
	                $data =mysqli_fetch_array($sql_costumer); 
	                ?>
	       

	                	<form class="form-vertikal" method="post" action="proses.php" enctype="multipart/form-data">
	                		<div class="form-group">
	                			<label class="col-sm-3">Nama Ibu</label>
	                			<div class="col-sm-7">
	                				<input type="hidden" name="id" value="<?=$data['ibu_id']?>">
	                				<input type="text" name="nama_ibu" value="<?=$data['ibu_nama']?>" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Alamat</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="alamat" value="<?=$data['alamat']?>" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Nama Suami</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="suami" value="<?=$data['suami']?>" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Tanggal Lahir</label>
	                			<div class="col-sm-7">
	                				<input type="date" name="tgl_lahir" value="<?=$data['tgl_lahir']?>" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Kelompok</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="kelompok" value="<?=$data['kelompok']?>" class="form-control">
	                				<input type="hidden" name="tgl_meninggal" value="<?=$data['tgl_meninggal']?>" class="form-control">
	                				<input type="hidden" name="penyebab" value="<?=$data['penyebab']?>" class="form-control">
	                			</div>
	                		</div>
	                		<!-- <div class="form-group">
	                			<label class="col-sm-3">Tanggal Meninggal</label>
	                			<div class="col-sm-7">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Penyebab</label>
	                			<div class="col-sm-7">
	                			</div>
	                		</div> -->
	                		<div class="form-group">
	                			<label class="col-sm-3">Tahapan</label>
	                			<div class="col-sm-7">
	                				<select class="form-control" name="tahapan">
	                					<option value="<?=$data['tahapan']?>"><?=$data['tahapan']?></option>
	                					<option value="0">Berhenti</option>
	                					<option value="1">Bejalan</option>
	                				</select>
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Keadaan</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="keadaan" value="<?=$data['keadaan']?>" class="form-control">
	                			</div>
	                		</div>
	                		<hr>

	                		<div class="form-group">
	                			<label class="col-sm-2"></label>
	                			<button type="submit" name="edit" class="btn btn-success">Simpan</button>
	                			</div>

	                	</form>

    					</div>

		          </div>
		        </div>
          

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>