<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php include '../../_config/config.php'; 
$title = "Data Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include 'navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <a href="add.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Ibu</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Ibu</th>
                      <th>Alamat</th>
                      <th>Suami</th>
                      <th>Tanggal Lahir</th>
                      <th>Kelompok</th>
                      <!-- <th>Tgl Meninggal</th>
                      <th>Penyebab</th> -->
                      <th>Tahapan</th>
                      <th>Keadaan</th>
                      <th><i class="fa fa-cogs"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_ibu") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) {
                           $a= $data['tahapan'];
                           if ($a=="1") {
                             $kms = "Berjalan";
                           }else{
                            $kms = "Berhenti";
                           } ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['ibu_nama'] ?></td>
                          <td><?= $data['alamat'] ?></td>
                          <td><?= $data['suami'] ?></td>
                          <td><?= $data['tgl_lahir'] ?></td>
                          <td><?= $data['kelompok'] ?></td>
                         <!--  <td><?= $data['tgl_meninggal'] ?></td>
                          <td><?= $data['penyebab'] ?></td> -->
                          <td><?= $kms ?></td>
                          <td><?= $data['keadaan'] ?></td>
                          <td class="text-center">
                           <a href="edit.php?id=<?=$data['ibu_id']?>" onclick="edit()" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                            <a href="delete.php?id=<?=$data['ibu_id']?>" onclick="hapus()" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>

                    </table>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>