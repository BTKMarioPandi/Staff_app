<?php
require_once "../../_config/config.php";
$id = @$_GET['id'];
mysqli_query($con, "DELETE FROM tb_ibu WHERE ibu_id = '$id'") or die (mysqli_error($con));
echo "<script>window.location='ibu.php';</script>";
?>