<?php
require_once "../../_config/config.php";

$nama_gambar 	= $_FILES['foto']['name'];
$lokasi_gambar 	= $_FILES['foto']['tmp_name'];
$tipe_gambar 	= $_FILES['foto']['type'];
$imageFileType 	= strtolower(pathinfo($nama_gambar,PATHINFO_EXTENSION));
move_uploaded_file($lokasi_gambar,"foto/$nama_gambar");

$id 		="";
$nama_user 	= trim(mysqli_real_escape_string($con, $_POST['nama']));
$username 	= trim(mysqli_real_escape_string($con, $_POST['username']));
$password	= md5($_POST['password']);
$role 		= trim(mysqli_real_escape_string($con, $_POST['role']));
$foto 		=$nama_gambar;

if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_user VALUES ('$id','$nama_user','$username','$password','$role','$foto')") or die (mysqli_error($con));
	echo "<script>window.location='user.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	
	mysqli_query($con, "UPDATE tb_user SET user_nama='$nama_user',username='$username',password='$password',foto='$foto',role='$role' WHERE user_id='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='anak.php';</script>";
}
?>