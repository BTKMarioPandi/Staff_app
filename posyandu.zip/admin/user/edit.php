<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>
<?php include '../../_config/config.php'; 
$title = "Data Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <!-- Page Heading -->
          
          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Edit Data Anak</h1>

          <div class="row">

            <div class="col-lg-10">

              <!-- Circle Buttons -->
              <div class="card shadow mb-4">
	                <div class="card-header py-3">
	                  <h6 class="m-0 font-weight-bold text-primary">Form Edit Data Anak</h6>
	                </div>

	                <?php 
	                $id= @$_GET['id'];
	                $sql_costumer=mysqli_query($con, "SELECT * FROM tb_user WHERE user_id = '$id' ")or die (mysqli_error($con));
	                $data =mysqli_fetch_array($sql_costumer); 
	                ?>
	       

	                	<form class="form-vertikal" method="post" action="proses.php" enctype="multipart/form-data">
	                		<div class="form-group">
	                			<label class="col-sm-3">Nama User</label>
	                			<div class="col-sm-7">
	                				<input type="hidden" name="id" value="<?=$data['user_id']?>>
	                				<input type="text" name="nama" value="<?=$data['user_nama']?> class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Username</label>
	                			<div class="col-sm-7">
	                				<input type="text" name="username" value="<?=$data['username']?>" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Password</label>
	                			<div class="col-sm-7">
	                				<input type="password" name="password" class="form-control">
	                			</div>
	                		</div>
	                		<div class="form-group">
	                			<label class="col-sm-3">Hak Akses</label>
	                			<div class="col-sm-7">
	                				<select class="form-control" name="role">
	                					<option value="<?=$data['role']?>"><?=$data['role']?></option>
	                					<option value="Admin">Admin</option>
	                					<option value="Kader">Kader</option>
	                				</select>
	                			</div>
	                		</div>
	                	<img src="foto/<?=$data['foto']?>" width="150px">
	                		<div class="form-group">
	                			<label class="col-sm-3">foto</label>
	                			<div class="col-sm-7">
	                				<input type="file" name="foto" class="form-control">
	                			</div>
	                		</div>
	                		
	                		<hr>

	                		<div class="form-group">
	                			<label class="col-sm-2"></label>
	                			<button type="submit" name="edit" class="btn btn-success">Edit</button>
	                			</div>

	                	</form>

    					</div>

		          </div>
		        </div>
          

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php 
}
?>