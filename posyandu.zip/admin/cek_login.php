<?php
include '../_config/config.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql	 = "SELECT * FROM tb_user WHERE username='$username' AND password='$password' ";
$result  = mysqli_query($con, $sql);
$ketemu  = mysqli_num_rows($result);
$r 		 = mysqli_fetch_assoc($result);
	if ($ketemu > 0)
	 {
	session_start();
	$_SESSION['username']	= $r['user_nama'];
	$_SESSION['password']	= $r['password'];
	$_SESSION['role']		= $r['role'];
	$_SESSION['foto']		= $r['foto'];




	echo "<script language='javascript'>alert('Selamat Anda berhasil Login');location.replace('index.php')</script>";
	}
	else {
		
	echo "<script language='javascript'>alert('Maaf Username & Password Tidak Sesuai');location.replace('login.php')</script>";

	}

?>