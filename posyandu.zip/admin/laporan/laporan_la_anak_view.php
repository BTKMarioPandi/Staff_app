<?php
include '../../_config/config.php'; 
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php 
$title = "Data Layanan Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>


        <!-- Begin Page Content -->
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
  <form method="post" action="la_la_anak.php" enctype="multipart/form-data">Periode 
 :<input type="date" name="tgl_awal" required=""> Sampai :<input type="date" name="tgl_akhir" required="">
<button type="submit" target="_blank" class="btn btn-sm btn-success"><i class="fa fa-print"></i> Print</button></form>
            
          </div>
    <br><br>
    <div class="card">
    <div class="row">
      <div class="col-sm-3 offset-1">
        
    <img src="../../frontend/img/logo.png" width="100px">
      </div>
      <div class="col-sm-6">
      <h3>Laporan Posyandu<br><strong> Desa Rimo Panjang</strong></h3>
  
      </div>
    </div>
      <div class="row">
        <div class="col-sm-6">
          <table class="table">
          <tr>
            <td>Posyandu</td>
            <td>:</td>
            <td>Kuntum Wijaya Kusuma 2B <br>RT:05, RT:06, RT:09 Graha Prima RW:016</td>
          </tr>
          <br>
          </table>
          <STRONG>Laporan Layanan Anak :</STRONG>
          <table class="table">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Anak</th>
                <th>Nama Ibu</th>
                <th>Tanggal Layanan</th>
                <th>Pelayanan</th>
                <th>Imunisasi</th>
                <th>Tinggi Badan</th>
                <th>Berat Badan</th>
                <th>Umur</th>
                <th>IMT</th>
                <th>BB berdasarkan TB</th>
                <th>BB berdasarkan Umur</th>
                <th>TB berdasarkan Umur</th>
                <th>IMT berdasarkan Umur</th>
              </tr>
            </thead>
            <tbody>
                <?php
                  $no = 1;
                  $sql = mysqli_query($con, "SELECT * FROM tb_la_anak 
                    JOIN tb_ibu ON tb_la_anak.ibu_id = tb_ibu.ibu_id 
                    JOIN tb_anak ON tb_la_anak.anak_id = tb_anak.anak_id") or die (mysqli_error($con));
                  while ($data = mysqli_fetch_array($sql)) { ?>
                <tr>
                  <td><?= $no++ ?>.</td>
                  <td><?= $data['ibu_nama'] ?></td>
                  <td><?= $data['anak_nama'] ?></td>
                  <td><?= $data['tgl_la_anak'] ?></td>
                  <td><?= $data['pelayanan'] ?></td>
                  <td><?= $data['imunisasi_anak'] ?></td>
                  <td><?= $data['tinggi_badan'] ?></td>
                  <td><?= $data['berat_badan'] ?></td>
                  <td><?= $data['umur'] ?></td>
                  <td><?= $data['imt'] ?></td>
                  <td><?= $data['bb_tb'] ?></td>
                  <td><?= $data['bb_u'] ?></td>
                  <td><?= $data['tb_u'] ?></td>
                  <td><?= $data['imt_u'] ?></td>
                </tr>
                <?php
                  }
                  ?>
            </tbody>
          </table>
        </div>
      </div>
      <hr>
          <div class="text-right">
            <strong>Petugas Posyandu</strong>
            <br>
            <br>
            (___________________)
          </div>
    </div>
  </div>
      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>