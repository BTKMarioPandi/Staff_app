<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>


<?php include '../../_config/config.php'; 
$title = "Laporan Layanan Anak";

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Posyandu - <?= $title ?></title>

  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/css/sb-admin-2.min.css" rel="stylesheet">

  <div class="container">
    <br><br>
    <div class="row">
      <div class="col-sm-3 offset-1 text-right">
        
    <img src="../../frontend/img/logo.png" width="80px">
      </div>
      <div class="col-sm- text-center ">
      <h3 >Laporan Posyandu<br><strong> Desa Rimo Panjang</strong></h3>
  
      </div>
    </div><hr>
      <div class="row">
        <div class="col-sm-6">
          <table class="table">
          <tr>
            <td>Posyandu</td>
            <td>:</td>
            <td>Kuntum Wijaya Kusuma 2B <br>RT:05, RT:06, RT:09 Graha Prima RW:016</td>
          </tr>
          <?php 
          $a = $_POST['tgl_awal'];
          $b = $_POST['tgl_akhir'];
          ?>
          <tr>
            <td>Periode</td>
            <td>:</td>
            <td><?= $a ?> s/d <?= $b ?></td>
          </tr>
          <br>

        </div>
      </div>
          </table>
          <STRONG>Laporan Layanan Anak :</STRONG>
          <table border="1">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Anak</th>
                <th>Nama Ibu</th>
                <th>Tanggal Layanan</th>
                <th>Pelayanan</th>
                <th>Imunisasi</th>
                <th>Tinggi Badan</th>
                <th>Berat Badan</th>
                <th>Umur</th>
                <th>IMT</th>
                <th>BB berdasarkan TB</th>
                <th>BB berdasarkan Umur</th>
                <th>TB berdasarkan Umur</th>
                <th>IMT berdasarkan Umur</th>
              </tr>
            </thead>
            <tbody>
                <?php
                  $no = 1;
                  $sql = mysqli_query($con, "SELECT * FROM tb_la_anak 
                    JOIN tb_ibu ON tb_la_anak.ibu_id = tb_ibu.ibu_id 
                    JOIN tb_anak ON tb_la_anak.anak_id = tb_anak.anak_id where tgl_la_anak BETWEEN '$a' AND '$b' ") or die (mysqli_error($con));
                  while ($data = mysqli_fetch_array($sql)) { ?>
                <tr>
                  <td><?= $no++ ?>.</td>
                  <td><?= $data['ibu_nama'] ?></td>
                  <td><?= $data['anak_nama'] ?></td>
                  <td><?= $data['tgl_la_anak'] ?></td>
                  <td><?= $data['pelayanan'] ?></td>
                  <td><?= $data['imunisasi_anak'] ?></td>
                  <td><?= $data['tinggi_badan'] ?></td>
                  <td><?= $data['berat_badan'] ?></td>
                  <td><?= $data['umur'] ?></td>
                  <td><?= $data['imt'] ?></td>
                  <td><?= $data['bb_tb'] ?></td>
                  <td><?= $data['bb_u'] ?></td>
                  <td><?= $data['tb_u'] ?></td>
                  <td><?= $data['imt_u'] ?></td>
                </tr>
                <?php
                  }
                  ?>
            </tbody>
          </table>
          <hr>
          <div class="text-right">
            <strong>Petugas Posyandu</strong>
            <br>
            <br>
            (___________________)
          </div>
        </div>
      </div>
      
    
  </div>  
</body>
<script type="text/javascript">
  window.print();
</script>
</html>
<?php } ?>