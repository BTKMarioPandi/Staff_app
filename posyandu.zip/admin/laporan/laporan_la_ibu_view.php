<?php
include '../../_config/config.php'; 
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php 
$title = "Data Layanan Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <form method="post" action="la_la_ibu.php" enctype="multipart/form-data">Periode 
 :<input type="date" name="tgl_awal" required=""> Sampai :<input type="date" name="tgl_akhir" required="">
<button type="submit" target="_blank" class="btn btn-sm btn-success"><i class="fa fa-print"></i> Print</button></form>
     
          </div>
    <br><br>
    <div class="card">
    <div class="row">
      <div class="col-sm-3 offset-1">
        
    <img src="../../frontend/img/logo.png" width="100px">
      </div>
      <div class="col-sm-6">
      <h3>Laporan Posyandu<br><strong> Desa Rimo Panjang</strong></h3>
  
      </div>
    </div>
      <div class="row">
        <div class="col-sm-6">
          <table class="table">
          <tr>
            <td>Posyandu</td>
            <td>:</td>
            <td>Kuntum Wijaya Kusuma 2B <br>RT:05, RT:06, RT:09 Graha Prima RW:016</td>
          </tr>
          <br>
          </table>
          <STRONG>Laporan Layanan Ibu :</STRONG>
          <table class="table">
            <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Ibu</th>
                      <th>Tanggal Layanan</th>
                      <th>Kehamilan</th>
                      <th>Resiko</th>
                      <th>Lila</th>
                      <th>PMT</th>
                      <th>Hasil</th>
                      <th>Darah</th>
                      <th>Imunisasi</th>
                      <th>Yodium</th>
                      <th>Vitamin A</th>
                    </tr>
                  </thead>
                <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_la_ibu INNER JOIN tb_ibu ON tb_la_ibu.ibu_id = tb_ibu.ibu_id") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) { ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['ibu_nama'] ?></td>
                          <td><?= $data['tgl_la'] ?></td>
                          <td><?= $data['kehamilan'] ?></td>
                          <td><?= $data['resiko'] ?></td>
                          <td><?= $data['lila'] ?></td>
                          <td><?= $data['pmt'] ?></td>
                          <td><?= $data['hasil'] ?></td>
                          <td><?= $data['darah'] ?></td>
                          <td><?= $data['imunisasi'] ?></td>
                          <td><?= $data['yodium'] ?></td>
                          <td><?= $data['vitamin'] ?></td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>
          </table>
          <div class="text-right">
            <strong>Petugas Posyandu</strong>
            <br>
            <br>
            (___________________)
          </div>
        </div>
      <hr>
      </div>
    </div>
  </div>
      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>