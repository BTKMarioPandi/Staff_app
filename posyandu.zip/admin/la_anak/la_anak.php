<?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
        include 'login.php';
    }
    else
    {
    
?>




<?php include '../../_config/config.php'; 
$title = "Data Layanan Ibu";
include '../head.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
<?php include '../navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Layanan Anak</h1>
            <a href="add.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Layanan Anak</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Anak</th>
                      <th>Nama Ibu</th>
                      <th>Tanggal Layanan</th>
                      <th>Pelayanan</th>
                      <th>Imunisasi</th>
                      <th>Tinggi Badan</th>
                      <th>Berat Badan</th>
                      <th>Umur</th>
                      <th>IMT</th>
                      <th>BB berdasarkan TB</th>
                      <th>BB berdasarkan Umur</th>
                      <th>TB berdasarkan Umur</th>
                      <th>IMT berdasarkan Umur</th>

                      <th><i class="fa fa-cogs"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                          $no = 1;
                          $sql = mysqli_query($con, "SELECT * FROM tb_la_anak 
                            JOIN tb_ibu ON tb_la_anak.ibu_id = tb_ibu.ibu_id 
                            JOIN tb_anak ON tb_la_anak.anak_id = tb_anak.anak_id") or die (mysqli_error($con));
                          while ($data = mysqli_fetch_array($sql)) { ?>
                        <tr>
                          <td><?= $no++ ?>.</td>
                          <td><?= $data['ibu_nama'] ?></td>
                          <td><?= $data['anak_nama'] ?></td>
                          <td><?= $data['tgl_la_anak'] ?></td>
                          <td><?= $data['pelayanan'] ?></td>
                          <td><?= $data['imunisasi_anak'] ?></td>
                          <td><?= $data['tinggi_badan'] ?></td>
                          <td><?= $data['berat_badan'] ?></td>
                          <td><?= $data['umur'] ?></td>
                          <td><?= $data['imt'] ?></td>
                          <td><?= $data['bb_tb'] ?></td>
                          <td><?= $data['bb_u'] ?></td>
                          <td><?= $data['tb_u'] ?></td>
                          <td><?= $data['imt_u'] ?></td>
                          <td class="text-center">
                           <a href="edit.php?id=<?=$data['la_id']?>" onclick="edit()" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                            <a href="delete.php?id=<?=$data['la_id']?>" onclick="hapus()" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        <?php
                          }
                          ?>
                    </tbody>

                    </table>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Posyandu Desa Rimbo Panjang</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php include '../footer.php'; ?>

</body>

</html>
<?php } ?>