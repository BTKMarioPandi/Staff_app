<?php
require_once "../../_config/config.php";
$id = @$_GET['id'];
mysqli_query($con, "DELETE FROM tb_la_anak WHERE la_id = '$id'") or die (mysqli_error($con));
echo "<script>window.location='la_anak.php';</script>";
?>