<?php
require_once "../../_config/config.php";

$id 		="";
$nama_anak 	= trim(mysqli_real_escape_string($con, $_POST['anak_id']));
$nama_ibu 	= trim(mysqli_real_escape_string($con, $_POST['ibu_id']));
$tgl 	= trim(mysqli_real_escape_string($con, $_POST['tl']));
$ply	= trim(mysqli_real_escape_string($con, $_POST['ply']));
$imun	= trim(mysqli_real_escape_string($con, $_POST['imn']));
$tb 	= trim(mysqli_real_escape_string($con, $_POST['tb']));
$bb 	= trim(mysqli_real_escape_string($con, $_POST['bb']));
$umur 	= trim(mysqli_real_escape_string($con, $_POST['u']));
$imt 	= trim(mysqli_real_escape_string($con, $_POST['imt']));
$bb_tb 	= trim(mysqli_real_escape_string($con, $_POST['bbtb']));
$bb_u 	= trim(mysqli_real_escape_string($con, $_POST['bbu']));
$tb_u 	= trim(mysqli_real_escape_string($con, $_POST['tbu']));
$imt_u 	= trim(mysqli_real_escape_string($con, $_POST['imtu']));

if(isset($_POST['add'])){
	mysqli_query($con, "INSERT INTO tb_la_anak VALUES ('$id','$nama_anak','$nama_ibu','$tgl','$ply','$imun','$tb','$bb','$umur','$imt','$bb_tb','$bb_u','$tb_u','$imt_u')") or die (mysqli_error($con));
	echo "<script>window.location='la_anak.php';</script>";
}else if(isset($_POST['edit'])){
	
	$id = $_POST['id'];
	mysqli_query($con, "UPDATE tb_la_anak SET anak_id='$nama_anak',ibu_id='$nama_ibu',tgl_la_anak='$tgl',pelayanan='$ply',imunisasi_anak='$imun',tinggi_badan='$tb',berat_badan='$bb',umur='$umur',imt='$imt',bb_tb='$bb_tb',bb_u='$bb_u',tb_u='$tb_u',imt_u='$imt_u' WHERE la_id='$id' ") or die (mysqli_error($con));
	echo "<script>window.location='la_anak.php';</script>";
}
?>

	



